﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using appFitness;
using System;

namespace appFitness.Tests
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void User_PropertiesSetCorrectly()
        {
            var user = new User
            {
                UserId = 1,
                Role = "admin",
                FirstName = "Анна",
                LastName = "Иванова",
                Patronymic = "Сергеевна"
            };

            Assert.AreEqual(1, user.UserId);
            Assert.AreEqual("admin", user.Role);
            Assert.AreEqual("Анна", user.FirstName);
            Assert.AreEqual("Иванова", user.LastName);
        }

        [TestMethod]
        public void Client_PropertiesSetCorrectly()
        {
            var client = new Client
            {
                ClientId = 5,
                FirstName = "Екатерина",
                LastName = "Морозова",
                Phone = "+79001112233",
                Email = "morozova@mail.ru"
            };

            Assert.AreEqual(5, client.ClientId);
            Assert.AreEqual("Екатерина", client.FirstName);
            Assert.AreEqual("Морозова", client.LastName);
            Assert.AreEqual("+79001112233", client.Phone);
        }

        [TestMethod]
        public void Subscription_PropertiesSetCorrectly()
        {
            var sub = new Subscription
            {
                SubscriptionId = 1,
                ClientId = 2,
                ClientName = "Морозова Екатерина",
                Type = "Месячный",
                Price = 2500.00m,
                StartDate = new DateTime(2026, 3, 1),
                EndDate = new DateTime(2026, 4, 1),
                Status = "Активен"
            };

            Assert.AreEqual("Месячный", sub.Type);
            Assert.AreEqual(2500.00m, sub.Price);
            Assert.AreEqual("Активен", sub.Status);
            Assert.AreEqual(new DateTime(2026, 3, 1), sub.StartDate);
        }

        [TestMethod]
        public void Subscription_IsExpired_WhenEndDateInPast()
        {
            var sub = new Subscription
            {
                EndDate = new DateTime(2025, 1, 1),
                Status = "Истёк"
            };

            Assert.AreEqual("Истёк", sub.Status);
            Assert.IsTrue(sub.EndDate < DateTime.Today);
        }

        [TestMethod]
        public void ClassItem_PropertiesSetCorrectly()
        {
            var classItem = new ClassItem
            {
                ClassId = 1,
                Name = "Йога для начинающих",
                ClassDate = new DateTime(2026, 4, 7),
                StartTime = "10:00",
                Duration = 60,
                TrainerName = "Козлова Мария",
                HallName = "Зал аэробики"
            };

            Assert.AreEqual("Йога для начинающих", classItem.Name);
            Assert.AreEqual(60, classItem.Duration);
            Assert.AreEqual("10:00", classItem.StartTime);
        }

        [TestMethod]
        public void VisitItem_StatusCanBeChanged()
        {
            var visit = new VisitItem
            {
                VisitId = 1,
                ClientName = "Морозова Екатерина",
                Status = "Записан"
            };

            visit.Status = "Пришёл";

            Assert.AreEqual("Пришёл", visit.Status);
        }

        [TestMethod]
        public void HallItem_CapacityIsPositive()
        {
            var hall = new HallItem
            {
                HallId = 1,
                Name = "Зал аэробики",
                Capacity = 20
            };

            Assert.AreEqual("Зал аэробики", hall.Name);
            Assert.IsTrue(hall.Capacity > 0);
        }
    }
}