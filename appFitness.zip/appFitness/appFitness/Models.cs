﻿using System;

namespace appFitness
{
    public class Client
    {
        public int ClientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }

    public class Subscription
    {
        public int SubscriptionId { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string Type { get; set; }
        public decimal Price { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Status { get; set; }
    }

    public class ClassItem
    {
        public int ClassId { get; set; }
        public string Name { get; set; }
        public DateTime ClassDate { get; set; }
        public string StartTime { get; set; }
        public int Duration { get; set; }
        public string TrainerName { get; set; }
        public string HallName { get; set; }
    }
    public class TrainerItem
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
    }

    public class HallItem
    {
        public int HallId { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
    }

    public class VisitItem
    {
        public int VisitId { get; set; }
        public string ClientName { get; set; }
        public string Status { get; set; }
    }

    public class ClientComboItem
    {
        public int ClientId { get; set; }
        public string FullName { get; set; }
    }
}