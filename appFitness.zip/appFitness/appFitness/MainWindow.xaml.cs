﻿using System.Data.SqlClient;
using System.Windows;

namespace appFitness
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ErrorText.Visibility = Visibility.Visible;
                return; 
            }

            User user = FindUser(login, password);

            if (user == null)
            {
                ErrorText.Visibility = Visibility.Visible;
            }
            else
            {
                ErrorText.Visibility = Visibility.Collapsed;
                OpenRoleWindow(user);
            }
        }

        private User FindUser(string login, string password)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT UserId, Role, FirstName, LastName, Patronymic
                                 FROM Users
                                 WHERE Login = @Login AND Password = @Password";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@Password", password);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                UserId = (int)reader["UserId"],
                                Role = reader["Role"].ToString(),
                                FirstName = reader["FirstName"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                Patronymic = reader["Patronymic"].ToString()
                            };
                        }
                    }
                }
            }
            return null; 
        }

        private void OpenRoleWindow(User user)
        {
            Window window = null;

            switch (user.Role)
            {
                case "admin":
                    window = new AdminWindow(user);
                    break;
                case "manager":
                    window = new ManagerWindow(user);
                    break;
                case "trainer":
                    window = new TrainerWindow(user);
                    break;
                default:
                    MessageBox.Show("Неизвестная роль пользователя");
                    return;
            }

            window.Show(); 
            this.Close();  
        }
    }
}
