﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace appFitness
{
    /// <summary>
    /// Логика взаимодействия для TrainerWindow.xaml
    /// </summary>
    public partial class TrainerWindow : Window
    {
        private User _currentUser;
        public TrainerWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            HeaderText.Text = $"Тренер: {user.LastName} {user.FirstName}";

            DateTime monday = GetMonday(DateTime.Today);
            DateTime sunday = monday.AddDays(6);
            WeekRangeText.Text = $"{monday:dd.MM.yyyy} — {sunday:dd.MM.yyyy}";

            LoadSchedule();
        }
        private DateTime GetMonday(DateTime date)
        {
            int diff = (int)date.DayOfWeek - (int)DayOfWeek.Monday;
            if (diff < 0) diff += 7;
            return date.AddDays(-diff);
        }

        private void LoadSchedule()
        {
            var classes = new List<ClassItem>();

            DateTime monday = GetMonday(DateTime.Today);
            DateTime sunday = monday.AddDays(6);

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT cl.ClassId, cl.Name, cl.ClassDate,
                                        CONVERT(VARCHAR(5), cl.StartTime, 108) AS StartTime,
                                        cl.Duration,
                                        h.Name AS HallName
                                 FROM Classes cl
                                 JOIN Halls h ON cl.HallId = h.HallId
                                 WHERE cl.TrainerId = @TrainerId
                                   AND cl.ClassDate >= @Monday
                                   AND cl.ClassDate <= @Sunday
                                 ORDER BY cl.ClassDate, cl.StartTime";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TrainerId", _currentUser.UserId);
                    cmd.Parameters.AddWithValue("@Monday", monday);
                    cmd.Parameters.AddWithValue("@Sunday", sunday);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            classes.Add(new ClassItem
                            {
                                ClassId = (int)reader["ClassId"],
                                Name = reader["Name"].ToString(),
                                ClassDate = (DateTime)reader["ClassDate"],
                                StartTime = reader["StartTime"].ToString(),
                                Duration = (int)reader["Duration"],
                                HallName = reader["HallName"].ToString()
                            });
                        }
                    }
                }
            }

            ScheduleGrid.ItemsSource = classes;

            if (classes.Count == 0)
                SelectedClassText.Text = "На этой неделе занятий нет";
        }

        private void ScheduleGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = ScheduleGrid.SelectedItem as ClassItem;
            if (selected == null) return;

            SelectedClassText.Text = $"{selected.Name} — {selected.ClassDate:dd.MM.yyyy} {selected.StartTime}";

            LoadClients(selected.ClassId);
        }

        private void LoadClients(int classId)
        {
            var visits = new List<VisitItem>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT v.VisitId,
                                        c.LastName + ' ' + c.FirstName AS ClientName,
                                        v.Status
                                 FROM Visits v
                                 JOIN Clients c ON v.ClientId = c.ClientId
                                 WHERE v.ClassId = @ClassId
                                 ORDER BY c.LastName";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ClassId", classId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            visits.Add(new VisitItem
                            {
                                VisitId = (int)reader["VisitId"],
                                ClientName = reader["ClientName"].ToString(),
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }
            }

            ClientsGrid.ItemsSource = visits;
        }

        private void MarkPresent_Click(object sender, RoutedEventArgs e)
        {
            MarkVisit("Пришёл");
        }

        private void MarkAbsent_Click(object sender, RoutedEventArgs e)
        {
            MarkVisit("Записан");
        }

        private void MarkVisit(string status)
        {
            var selected = ClientsGrid.SelectedItem as VisitItem;
            if (selected == null)
            {
                MessageBox.Show("Выберите клиента из списка");
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "UPDATE Visits SET Status = @Status WHERE VisitId = @Id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@Id", selected.VisitId);
                    cmd.ExecuteNonQuery();
                }
            }

            var selectedClass = ScheduleGrid.SelectedItem as ClassItem;
            if (selectedClass != null)
                LoadClients(selectedClass.ClassId);
        }
    }
}
