﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace appFitness
{
    public partial class ClassDialog : Window
    {
        private int? _classId;

        public ClassDialog(int? classId = null)
        {
            InitializeComponent();
            _classId = classId;
            LoadTrainers();
            LoadHalls();

            if (_classId != null)
            {
                Title = "Редактировать занятие";
                LoadClassData();
            }
        }

        private void LoadClassData()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT Name, ClassDate, 
                                CONVERT(VARCHAR(5), StartTime, 108) AS StartTime,
                                Duration, TrainerId, HallId
                         FROM Classes WHERE ClassId = @Id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", _classId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            NameBox.Text = reader["Name"].ToString();
                            DatePicker.SelectedDate = (DateTime)reader["ClassDate"];
                            TimeBox.Text = reader["StartTime"].ToString();
                            DurationBox.Text = reader["Duration"].ToString();
                            TrainerCombo.SelectedValue = (int)reader["TrainerId"];
                            HallCombo.SelectedValue = (int)reader["HallId"];
                        }
                    }
                }
            }
        }

        private void LoadTrainers()
        {
            var trainers = new List<TrainerItem>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT UserId, LastName + ' ' + FirstName AS FullName
                                 FROM Users WHERE Role = 'trainer'";

                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        trainers.Add(new TrainerItem
                        {
                            UserId = (int)reader["UserId"],
                            FullName = reader["FullName"].ToString()
                        });
                    }
                }
            }

            TrainerCombo.ItemsSource = trainers;
        }

        private void LoadHalls()
        {
            var halls = new List<HallItem>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT HallId, Name FROM Halls";

                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        halls.Add(new HallItem
                        {
                            HallId = (int)reader["HallId"],
                            Name = reader["Name"].ToString()
                        });
                    }
                }
            }

            HallCombo.ItemsSource = halls;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text) ||
                DatePicker.SelectedDate == null ||
                string.IsNullOrWhiteSpace(TimeBox.Text) ||
                string.IsNullOrWhiteSpace(DurationBox.Text) ||
                TrainerCombo.SelectedValue == null ||
                HallCombo.SelectedValue == null)
            {
                ErrorText.Text = "Заполните все поля";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            if (!int.TryParse(DurationBox.Text, out int duration))
            {
                ErrorText.Text = "Длительность должна быть числом";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = _classId == null
                    ? @"INSERT INTO Classes (Name, ClassDate, StartTime, Duration, TrainerId, HallId)
                VALUES (@Name, @Date, @Time, @Duration, @Trainer, @Hall)"
                    : @"UPDATE Classes SET
                Name = @Name, ClassDate = @Date, StartTime = @Time,
                Duration = @Duration, TrainerId = @Trainer, HallId = @Hall
                WHERE ClassId = @Id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", NameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Date", DatePicker.SelectedDate.Value);
                    cmd.Parameters.AddWithValue("@Time", TimeBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Duration", duration);
                    cmd.Parameters.AddWithValue("@Trainer", TrainerCombo.SelectedValue);
                    cmd.Parameters.AddWithValue("@Hall", HallCombo.SelectedValue);
                    if (_classId != null)
                        cmd.Parameters.AddWithValue("@Id", _classId);
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }

}