﻿using System.Data.SqlClient;
using System.Windows;

namespace appFitness
{
    public partial class ClientDialog : Window
    {
        private Client _client;

        public ClientDialog(Client client)
        {
            InitializeComponent();
            _client = client;

            if (_client != null)
            {
                Title = "Редактировать клиента";
                LastNameBox.Text = _client.LastName;
                FirstNameBox.Text = _client.FirstName;
                PatronymicBox.Text = _client.Patronymic;
                PhoneBox.Text = _client.Phone;
                EmailBox.Text = _client.Email;
            }
            else
            {
                Title = "Новый клиент";
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LastNameBox.Text) ||
                string.IsNullOrWhiteSpace(FirstNameBox.Text))
            {
                ErrorText.Text = "Заполните фамилию и имя";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            if (_client == null)
                InsertClient();
            else
                UpdateClient();
        }

        private void InsertClient()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"INSERT INTO Clients 
                                 (FirstName, LastName, Patronymic, Phone, Email)
                                 VALUES 
                                 (@First, @Last, @Patr, @Phone, @Email)";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@First", FirstNameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Last", LastNameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Patr", PatronymicBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", PhoneBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", EmailBox.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
        }

        private void UpdateClient()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"UPDATE Clients SET
                                 FirstName  = @First,
                                 LastName   = @Last,
                                 Patronymic = @Patr,
                                 Phone      = @Phone,
                                 Email      = @Email
                                 WHERE ClientId = @Id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@First", FirstNameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Last", LastNameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Patr", PatronymicBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", PhoneBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", EmailBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Id", _client.ClientId);
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}