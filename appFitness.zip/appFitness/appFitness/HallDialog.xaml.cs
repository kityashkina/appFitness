﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace appFitness
{
    /// <summary>
    /// Логика взаимодействия для HallDialog.xaml
    /// </summary>
    public partial class HallDialog : Window
    {
        private HallItem _hall;
        public HallDialog(HallItem hall)
        {
            InitializeComponent();
            _hall = hall;

            if (_hall != null)
            {
                Title = "Редактировать зал";
                NameBox.Text = _hall.Name;
                CapacityBox.Text = _hall.Capacity.ToString();
            }
            else
            {
                Title = "Новый зал";
            }
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text))
            {
                ErrorText.Text = "Введите название зала";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            if (!int.TryParse(CapacityBox.Text, out int capacity) || capacity <= 0)
            {
                ErrorText.Text = "Вместимость должна быть числом больше нуля";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = _hall == null
                    ? "INSERT INTO Halls (Name, Capacity) VALUES (@Name, @Capacity)"
                    : "UPDATE Halls SET Name = @Name, Capacity = @Capacity WHERE HallId = @Id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", NameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@Capacity", capacity);
                    if (_hall != null)
                        cmd.Parameters.AddWithValue("@Id", _hall.HallId);
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
