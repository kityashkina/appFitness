﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace appFitness
{
    /// <summary>
    /// Логика взаимодействия для SubscriptionDialog.xaml
    /// </summary>
    public partial class SubscriptionDialog : Window
    {
        private Subscription _subscription;
        public SubscriptionDialog(Subscription subscription)
        {
            InitializeComponent();
            _subscription = subscription;
            LoadClients();

            if (_subscription != null)
            {
                Title = "Редактировать абонемент";
                Loaded += OnLoaded;
            }
            else
            {
                Title = "Новый абонемент";
                StartDatePicker.SelectedDate = DateTime.Today;
            }
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            ClientCombo.SelectedValue = _subscription.ClientId;
            PriceBox.Text = _subscription.Price.ToString();
            StartDatePicker.SelectedDate = _subscription.StartDate;
            EndDatePicker.SelectedDate = _subscription.EndDate;

            SelectComboItem(TypeCombo, _subscription.Type);
            SelectComboItem(StatusCombo, _subscription.Status);
        }

        private void SelectComboItem(ComboBox combo, string value)
        {
            foreach (ComboBoxItem item in combo.Items)
            {
                if (item.Content.ToString() == value)
                {
                    combo.SelectedItem = item;
                    break;
                }
            }
        }

        private void LoadClients()
        {
            var clients = new List<ClientComboItem>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT ClientId, LastName + ' ' + FirstName AS FullName
                                 FROM Clients ORDER BY LastName";

                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        clients.Add(new ClientComboItem
                        {
                            ClientId = (int)reader["ClientId"],
                            FullName = reader["FullName"].ToString()
                        });
                    }
                }
            }

            ClientCombo.ItemsSource = clients;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientCombo.SelectedValue == null ||
                TypeCombo.SelectedItem == null ||
                string.IsNullOrWhiteSpace(PriceBox.Text) ||
                StartDatePicker.SelectedDate == null ||
                EndDatePicker.SelectedDate == null ||
                StatusCombo.SelectedItem == null)
            {
                ErrorText.Text = "Заполните все поля";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price < 0)
            {
                ErrorText.Text = "Цена должна быть числом";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            string type = (TypeCombo.SelectedItem as ComboBoxItem).Content.ToString();
            string status = (StatusCombo.SelectedItem as ComboBoxItem).Content.ToString();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = _subscription == null
                    ? @"INSERT INTO Subscriptions 
                        (ClientId, Type, Price, StartDate, EndDate, Status)
                        VALUES (@ClientId, @Type, @Price, @Start, @End, @Status)"
                    : @"UPDATE Subscriptions SET
                        ClientId = @ClientId, Type = @Type, Price = @Price,
                        StartDate = @Start, EndDate = @End, Status = @Status
                        WHERE SubscriptionId = @Id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ClientId", ClientCombo.SelectedValue);
                    cmd.Parameters.AddWithValue("@Type", type);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Start", StartDatePicker.SelectedDate.Value);
                    cmd.Parameters.AddWithValue("@End", EndDatePicker.SelectedDate.Value);
                    cmd.Parameters.AddWithValue("@Status", status);
                    if (_subscription != null)
                        cmd.Parameters.AddWithValue("@Id", _subscription.SubscriptionId);
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}

