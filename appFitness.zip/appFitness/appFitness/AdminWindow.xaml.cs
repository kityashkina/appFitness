﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using System.Windows;
using System.Windows.Controls;

namespace appFitness
{
    public partial class AdminWindow : Window
    {
        private User _currentUser;

        public AdminWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            HeaderText.Text = $"Администратор: {user.LastName} {user.FirstName}";

            LoadClients();
            LoadSubscriptions();
            LoadSchedule();
        }
        private void LoadClients(string search = "")
        {
            var clients = new List<Client>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT ClientId, FirstName, LastName, Patronymic, Phone, Email
                                 FROM Clients
                                 WHERE LastName LIKE @Search OR FirstName LIKE @Search
                                 ORDER BY LastName";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Search", "%" + search + "%");

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            clients.Add(new Client
                            {
                                ClientId = (int)reader["ClientId"],
                                FirstName = reader["FirstName"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                Patronymic = reader["Patronymic"].ToString(),
                                Phone = reader["Phone"].ToString(),
                                Email = reader["Email"].ToString()
                            });
                        }
                    }
                }
            }

            ClientsGrid.ItemsSource = clients;
        }

        private void ClientSearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadClients(ClientSearchBox.Text);
        }

        private void ClientsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }

        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ClientDialog(null);
            if (dialog.ShowDialog() == true)
            {
                LoadClients();
            }
        }

        private void EditClient_Click(object sender, RoutedEventArgs e)
        {
            var selected = ClientsGrid.SelectedItem as Client;
            if (selected == null)
            {
                MessageBox.Show("Выберите клиента для редактирования");
                return;
            }

            var dialog = new ClientDialog(selected);
            if (dialog.ShowDialog() == true)
            {
                LoadClients();
            }
        }

        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            var selected = ClientsGrid.SelectedItem as Client;
            if (selected == null)
            {
                MessageBox.Show("Выберите клиента для удаления");
                return;
            }

            var result = MessageBox.Show(
                $"Удалить клиента {selected.LastName} {selected.FirstName}?",
                "Подтверждение",
                MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string query = "DELETE FROM Clients WHERE ClientId = @Id";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", selected.ClientId);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadClients();
            }
        }


        private void LoadSubscriptions()
        {
            var subscriptions = new List<Subscription>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT s.SubscriptionId,
                                        c.LastName + ' ' + c.FirstName AS ClientName,
                                        s.Type, s.Price, s.StartDate, s.EndDate, s.Status
                                 FROM Subscriptions s
                                 JOIN Clients c ON s.ClientId = c.ClientId
                                 ORDER BY s.EndDate";

                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        subscriptions.Add(new Subscription
                        {
                            SubscriptionId = (int)reader["SubscriptionId"],
                            ClientName = reader["ClientName"].ToString(),
                            Type = reader["Type"].ToString(),
                            Price = (decimal)reader["Price"],
                            StartDate = (DateTime)reader["StartDate"],
                            EndDate = (DateTime)reader["EndDate"],
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }

            SubscriptionsGrid.ItemsSource = subscriptions;
        }


        private void LoadSchedule()
        {
            var classes = new List<ClassItem>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = @"SELECT cl.ClassId, cl.Name, cl.ClassDate, 
                                        CONVERT(VARCHAR(5), cl.StartTime, 108) AS StartTime,
                                        cl.Duration,
                                        u.LastName + ' ' + u.FirstName AS TrainerName,
                                        h.Name AS HallName
                                 FROM Classes cl
                                 JOIN Users u ON cl.TrainerId = u.UserId
                                 JOIN Halls h ON cl.HallId = h.HallId
                                 ORDER BY cl.ClassDate, cl.StartTime";

                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        classes.Add(new ClassItem
                        {
                            ClassId = (int)reader["ClassId"],
                            Name = reader["Name"].ToString(),
                            ClassDate = (DateTime)reader["ClassDate"],
                            StartTime = reader["StartTime"].ToString(),
                            Duration = (int)reader["Duration"],
                            TrainerName = reader["TrainerName"].ToString(),
                            HallName = reader["HallName"].ToString()
                        });
                    }
                }
            }

            ScheduleGrid.ItemsSource = classes;
        }

        private void AddClass_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ClassDialog();
            if (dialog.ShowDialog() == true)
            {
                LoadSchedule();
            }
        }
    }
}
